import pygame
import sys
import random
#initialise
pygame.init()
pygame.mixer.init()

#window parameter
window_spec=pygame.display.set_mode((800,600))
pygame.display.set_caption("Fun-Run")

def game_exit():
    pygame.init()
    global window_spec
    #line="Game Over"
    #lines=["Game Over","press ESC to quit","press RETURN to retry"]
    font=pygame.font.FontType("Retro Gaming.ttf",40)
    m=font.render("Game Over",True,(255,0,0))
    k=font.render("Press ESC to quit",True,(255,0,0))
    lo=font.render("Press ENTER to replay",True,(255,0,0))
    power=True
    sd2=pygame.mixer.Sound("sd2.mp3")
    global window_spec
    while power:
        for event in pygame.event.get():
            if event.type==pygame.QUIT:
                pygame.quit()
                #power=False
        j=pygame.key.get_pressed()
        if j[pygame.K_ESCAPE]:
            sd2.play()
            pygame.quit()
            sys.exit()
            #power=False
        if j[pygame.K_RETURN]:
            sd2.play()
            #intro_screen()
            main_game_loop(1.0)
        window_spec.fill((0,0,0))
        window_spec.blit(m,(250,250))
        window_spec.blit(k,(200,300))
        window_spec.blit(lo,(150,350))
        pygame.display.update();

def intro_screen():
    font=pygame.font.Font("Retro Gaming.ttf",45)
    kre=font.render("Welcome!",True,(255,0,0))
    lre=font.render("Press ENTER to start",True,(255,0,0))
    lv1=font.render("Press 1 for easy",True,(255,0,0))
    lv2=font.render("Press 2 for medium",True,(255,0,0))
    lv3=font.render("Press 3 for hard",True,(255,0,0))
    level=0.0
    power2=True
    while(power2):
        for event in pygame.event.get():
            if event.type==pygame.QUIT:
                power2=False
        keys=pygame.key.get_pressed()
        if keys[pygame.K_RETURN]:
            main_game_loop(level)
            power2=False
        if keys[pygame.K_1]:
            level=0.0
        if keys[pygame.K_2]:
            level=1.0
        if keys[pygame.K_3]:
            level=2.0
        window_spec.blit(kre,(250,150))
        window_spec.blit(lre,(100,200))
        window_spec.blit(lv1,(150,260))
        window_spec.blit(lv2,(150,350))
        window_spec.blit(lv3,(150,450))
        pygame.display.update()
def main_game_loop(hj):
    speed_i=hj
    vel=5
    x=500
    y=500
    power=True
    imag=pygame.image.load("ap.jpg")
    life =2 #actually 3 but its effect only on next cycle so 2
    sd1=pygame.mixer.Sound("sd1.mp3")
    sd2=pygame.mixer.Sound("sd2.mp3")
    
    listx=[12,234,445,570,699,100,312,500,600,517]
    listy=[-10,-50,-110,-140,-196,-70,-250,-312,-398,-425]
    lists=[2,2.25,2.3,2.5,2.75,2.1,2.29,2.45,2.65,2.33]
    def love():
        nonlocal life
        for i in range(life+1,0,-1):
            pygame.draw.rect(window_spec,(255,0,0),(650-(i*11),10,10,10))
    def reboot():
        #global x,y,
        nonlocal speed_i
        speed_i+=1/1000
        nonlocal power
        nonlocal life
        for i in range(0,10):
            listy[i]+=lists[i]
            if(x<=listx[i]<=x+40 and y<=listy[i]<=y+60):
                print("lost")
                if(life == 0):
                    power=False
                else:
                    life-=1
                    sd2.play()
            if(listy[i]>500):
                listy[i]-=random.randint(540,1000)
                listx[i]=random.randint(0,670)
                lists[i]=random.uniform(2+speed_i,3+speed_i)

            


    
    while power:
        pygame.time.delay(10)
        for event in pygame.event.get():
            if event.type==pygame.QUIT:
                pygame.quit()
                sys.exit()
        keys=pygame.key.get_pressed()
        if(keys[pygame.K_LEFT] and  x>=5):
            sd1.play()
            x-=vel
        if(keys[pygame.K_RIGHT]and x<=750):
            sd1.play()
            x+=vel
        '''if(keys[pygame.K_DOWN] and y<=550):
            y+=vel
        if(keys[pygame.K_UP] and y>=5):
            y-=vel'''
        window_spec.fill((17,17,17))
        reboot()
        #pygame.draw.rect(window_spec,(255,0,0),(x,y,40,60))
        window_spec.blit(imag,(x,y))
        pygame.draw.rect(window_spec,(255,255,255),(listx[0],listy[0],10,20))
        pygame.draw.rect(window_spec,(255,255,255),(listx[1],listy[1],10,20))
        pygame.draw.rect(window_spec,(255,255,255),(listx[2],listy[2],10,20))
        pygame.draw.rect(window_spec,(255,255,0),(listx[3],listy[3],10,20))
        pygame.draw.rect(window_spec,(255,255,255),(listx[4],listy[4],10,20))
        pygame.draw.rect(window_spec,(255,255,255),(listx[5],listy[5],10,20))
        pygame.draw.rect(window_spec,(255,0,255),(listx[6],listy[6],10,20))
        pygame.draw.rect(window_spec,(0,255,255),(listx[7],listy[7],10,20))
        pygame.draw.rect(window_spec,(255,255,255),(listx[8],listy[8],10,20))
        pygame.draw.rect(window_spec,(255,255,255),(listx[9],listy[9],10,20))
        love()
        #pygame.draw.rect(window_spec,(255,255.255),(x1))
        pygame.display.update()
    #sd1.play()
    game_exit()

#main_game_loop()
intro_screen()

